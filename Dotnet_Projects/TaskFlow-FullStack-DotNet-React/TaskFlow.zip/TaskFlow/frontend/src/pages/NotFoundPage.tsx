import { Link } from 'react-router-dom';

export function NotFoundPage() {
  return (
    <div className="flex h-screen flex-col items-center justify-center gap-3">
      <h1 className="text-4xl font-bold text-gray-800">404</h1>
      <p className="text-gray-500">Page not found.</p>
      <Link to="/tasks" className="text-brand-600 hover:underline">Go back home</Link>
    </div>
  );
}
